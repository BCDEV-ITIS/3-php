<?php
// TODO Récupérez les pays depuis le fichier JSON app/back/data/countries_and_cities.json
/**
 * Remplacez le tableau vide par le tableau des pays après traitement avec PHP
 * Exemple résultat finale attendu $countries = [["id" => 1, "name" => "France"],["id" => 2, "name" => "Belgique"]]
 * @var $countries
 */