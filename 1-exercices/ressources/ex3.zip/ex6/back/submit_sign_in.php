<?php

// TODO traitez la connexion depuis une soumission du formulaire de connexion côté front