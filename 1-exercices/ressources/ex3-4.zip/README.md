# Documentation exercices 3 et 4

## Structure de la base de données

![schema](./images/schema.jpg)

---

## Arborescence des dossiers

1. Dossier ***front/*** dédié aux pages et documents statiques tels que le css, js et les pages statiques HTML.
2. Dossier ***back/*** dédié aux pages dynamiques avec traitement des opérations par PHP telles que : 
- Récupération des pays
- Récupération des villes
- Inscription des utilisateurs
- Connexion des utilisateurs

---

## Lancement du Front

Lancez l'application Front avec l'extension VSCode Live server depuis le fichier ***/front/index.html***

## Lancement du Back

Créez un virtuel host avec Wamp pour associer la racine du dossier ***/back/*** à un nom de domaine local ou lancez un serveur PHP localhost avec la commande suivante