<?php
require_once __DIR__.'/functions/utils.php';
allowCors();