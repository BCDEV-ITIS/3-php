export function getCitiesFrom(url) {
  const countryElt = document.querySelector("[name=country]");
  if (!countryElt) return;
  countryElt.addEventListener("change", () => {
    fetch(encodeURI(`${url}?country=${countryElt.value}`), {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
      },
      method: "GET"
    })
      .then((data) => data.json())
      .then(({ data }) => {
        const { cities } = data;
        const selectCity = document.querySelector("[name=city");
        if (!selectCity) throw new Error("City select element does not exist");
        const options = selectCity.querySelectorAll('option:not([value="-1"])');
        if (options) options.forEach((opt) => opt.remove());
        cities.forEach((city) => {
          const option = document.createElement("option");
          option.value = city;
          option.innerText = city;
          selectCity.append(option);
        });
      })
      .catch((error) => console.error("error", error));
  });
}
