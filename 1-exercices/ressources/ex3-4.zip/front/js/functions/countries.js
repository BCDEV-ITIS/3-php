export function getCountries(url) {
  const countryElt = document.querySelector("[name=country]");
  if (!countryElt) return;
  fetch(url, {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
    },
    method: "GET"
  })
    .then((data) => data.json())
    .then(({ data }) => {
      const { countries } = data;
      const options = countryElt.querySelectorAll('option:not([value="-1"])');
      if (options) options.forEach((opt) => opt.remove());
      for (let i = 0; i < countries.length; i++) {
        const country = countries[i];
        const option = document.createElement("option");
        option.value = country;
        option.innerText = country;
        countryElt.append(option);
      }
    })
    .catch((error) => console.error("error", error));
}
