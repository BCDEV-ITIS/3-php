import { getCitiesFrom } from "./functions/city.js";
import { getCountries } from "./functions/countries.js";
const URI = `http://[back end url here]`;
// uncomment following functions
// getCountries(URI);
// getCitiesFrom(URI);